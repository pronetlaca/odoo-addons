/* /whatsapp_connector/static/src/main.js */
odoo.define('@whatsapp_connector/main',async function(require){'use strict';let __exports={};const{registry}=require('@web/core/registry')
const{Chatroom}=require('@whatsapp_connector/lib/lib17')
registry.category('actions').add('acrux.chat.conversation_tag',Chatroom)
return __exports;});
