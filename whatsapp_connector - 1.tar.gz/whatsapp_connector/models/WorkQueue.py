# -*- coding: utf-8 -*-
from odoo import models


class ChatWorkQueue(models.Model):
    _name = 'acrux.chat.work.queue'
    _description = 'Work Queue'
