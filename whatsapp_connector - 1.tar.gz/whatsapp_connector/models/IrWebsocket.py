# -*- coding: utf-8 -*-

from odoo import models


class IrWebsocket(models.AbstractModel):
    _inherit = 'ir.websocket'

    def _build_bus_channel_list(self, channels):
        user_id = self.env.uid
        if user_id and self.env.user.has_group('whatsapp_connector.group_chat_basic_extra'):
            company_id = self.env.context.get('allowed_company_ids', [self.env.company.id])[0]
            channels = list(channels)
            connector_ids = self.env['acrux.chat.connector'].connector_cache()
            for conn_id in connector_ids:
                channels.append((self.env.registry.db_name, 'acrux.chat.conversation', company_id, conn_id))
            channels.append((self.env.registry.db_name, 'acrux.chat.conversation', 'private', company_id, user_id))

        return super()._build_bus_channel_list(channels)
