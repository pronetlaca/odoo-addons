# -*- coding: utf-8 -*-
from . import WorkQueue
from . import Connector
from . import BaseMessage
from . import DefaultAnswer
from . import Conversation
from . import ConversationActivities
from . import Message
from . import ResUsers
from . import Product
from . import IrAttachment
from . import ResPartner
from . import ResConfigSettings
from . import MailTemplate
from . import Template
from . import TemplateParams
from . import IrWebsocket
